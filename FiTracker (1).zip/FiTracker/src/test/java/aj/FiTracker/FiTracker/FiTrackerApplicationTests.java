package aj.FiTracker.FiTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
