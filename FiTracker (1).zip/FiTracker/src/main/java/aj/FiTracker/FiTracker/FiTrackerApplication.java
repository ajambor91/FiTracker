package aj.FiTracker.FiTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FiTrackerApplication.class, args);
	}

}
